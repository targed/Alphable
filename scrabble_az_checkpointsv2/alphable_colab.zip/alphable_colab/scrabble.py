import pyspiel
import copy
import numpy as np
import collections
from structure import Gaddag, MoveGenerator

# Game Configuration
_NUM_PLAYERS = 2
_BOARD_SIZE = 15
_SHARED_GADDAG = None
_GAME_TYPE = pyspiel.GameType(
    short_name="scrabble",
    long_name="Scrabble (North American)",
    dynamics=pyspiel.GameType.Dynamics.SEQUENTIAL,
    chance_mode=pyspiel.GameType.ChanceMode.EXPLICIT_STOCHASTIC, # For tile drawing
    information=pyspiel.GameType.Information.IMPERFECT_INFORMATION,
    utility=pyspiel.GameType.Utility.ZERO_SUM,
    reward_model=pyspiel.GameType.RewardModel.TERMINAL, # Or rewards per turn
    max_num_players=_NUM_PLAYERS,
    min_num_players=_NUM_PLAYERS,
    provides_information_state_string=True,
    provides_information_state_tensor=True,
    provides_observation_string=True,
    provides_observation_tensor=True,
    parameter_specification={}
)

_GAME_INFO = pyspiel.GameInfo(
    num_distinct_actions=100000,  # Large action space for Scrabble
    max_chance_outcomes=100,  # Drawing tiles from bag
    num_players=_NUM_PLAYERS,
    min_utility=-1000.0,  # Conservative estimate for score differences
    max_utility=1000.0,
    utility_sum=0.0,  # Zero-sum game
    max_game_length=500  # Rough upper bound on number of moves
)
# Standard Tile Values
TILE_VALUES = {
    'A': 1, 'B': 3, 'C': 3, 'D': 2, 'E': 1, 'F': 4, 'G': 2, 'H': 4, 'I': 1, 
    'J': 8, 'K': 5, 'L': 1, 'M': 3, 'N': 1, 'O': 1, 'P': 3, 'Q': 10, 'R': 1, 
    'S': 1, 'T': 1, 'U': 1, 'V': 4, 'W': 4, 'X': 8, 'Y': 4, 'Z': 10, '?': 0, '.': 0
}

# Standard Bag Distribution (Letter, Count)
BAG_DISTRIBUTION = [
    ('A', 9), ('B', 2), ('C', 2), ('D', 4), ('E', 12), ('F', 2), ('G', 3), 
    ('H', 2), ('I', 9), ('J', 1), ('K', 1), ('L', 4), ('M', 2), ('N', 6), 
    ('O', 8), ('P', 2), ('Q', 1), ('R', 6), ('S', 4), ('T', 6), ('U', 4), 
    ('V', 2), ('W', 2), ('X', 1), ('Y', 2), ('Z', 1), ('?', 2)
]

# Premium Squares: (Row, Col) -> Multiplier Type
# 1=DL, 2=TL, 3=DW, 4=TW
PREMIUMS = {}
# Initialize standard layout (Partial visualization)
# Triple Word (TW)
for r, c in [(0,0), (0,7), (0,14), (7,0), (7,14), (14,0), (14,7), (14,14)]:
    PREMIUMS[(r,c)] = ('W', 3)
# Double Word (DW)
for r in [1, 2, 3, 4, 10, 11, 12, 13]:
    PREMIUMS[(r, r)] = ('W', 2)
    PREMIUMS[(r, 14-r)] = ('W', 2)
PREMIUMS[(7,7)] = ('W', 2) # Center star
# Triple Letter (TL)
for r, c in [(1,5), (1,9), (5,1), (5,5), (5,9), (5,13), 
             (9,1), (9,5), (9,9), (9,13), (13,5), (13,9)]:
    PREMIUMS[(r,c)] = ('L', 3)
# Double Letter (DL) - Fill in the rest explicitly or procedurally
DL_COORDS = [
    (0,3), (0,11), (2,6), (2,8), (3,0), (3,7), (3,14), (6,2), (6,6), (6,8), (6,12),
    (7,3), (7,11), (8,2), (8,6), (8,8), (8,12), (11,0), (11,7), (11,14),
    (12,6), (12,8), (14,3), (14,11)
]
for r, c in DL_COORDS:
    PREMIUMS[(r,c)] = ('L', 2)

class ScrabbleGame(pyspiel.Game):
    def __init__(self, params=None):
        super().__init__(_GAME_TYPE, _GAME_INFO, params if params else {})
        
        # Load GADDAG only once per process
        global _SHARED_GADDAG
        if _SHARED_GADDAG is None:
            _SHARED_GADDAG = Gaddag.load("NWL2023.txt")
            
        self.gaddag = _SHARED_GADDAG
        self.move_gen = MoveGenerator(self.gaddag)
        
    def num_distinct_actions(self):
        return 452

    def observation_tensor_shape(self):
        return [35, 15, 15]

    def new_initial_state(self):
        return ScrabbleState(self)

class ScrabbleState(pyspiel.State):
    def __init__(self, game):
        super().__init__(game)
        # Use lists of characters for the board (easier for GADDAG)
        self.board = [['.' for _ in range(15)] for _ in range(15)]
        self.scores = [0.0, 0.0]
        self._game_over = False
        self._current_player = 0
        self._current_move_map = [] # Stores valid moves for the current turn
        self.consecutive_passes = 0
        self.turn_count = 0
        
        # Initialize Bag
        self.bag = []
        for letter, count in BAG_DISTRIBUTION:
            self.bag.extend([letter] * count)
        np.random.shuffle(self.bag) # Shuffle immediately
        
        # Draw initial racks (7 tiles each)
        self.racks = [[], []]
        self._refill_rack(0)
        self._refill_rack(1)
        
    def clone(self):
        """
        Critical for MCTS: Return a deep copy of the state.
        Without this, simulating moves corrupts the parent state's board.
        """
        return copy.deepcopy(self)

    def _refill_rack(self, player_idx):
        needed = 7 - len(self.racks[player_idx])
        if needed > 0 and self.bag:
            draw = [self.bag.pop() for _ in range(min(needed, len(self.bag)))]
            self.racks[player_idx].extend(draw)

    def current_player(self):
        return self._current_player
    
    def _validate_move(self, row, col, word, direction, rack):
        """
        Returns (True, tiles_used) if valid, (False, None) otherwise.
        Checks: Boundaries, Connectivity, Rack availability.
        """
        dr, dc = (0, 1) if direction == 'Across' else (1, 0)
        
        # 1. Boundary Check
        end_r = row + dr * (len(word) - 1)
        end_c = col + dc * (len(word) - 1)
        if not (0 <= row < 15 and 0 <= col < 15 and 0 <= end_r < 15 and 0 <= end_c < 15):
            return False, None

        # 2. Connectivity & Rack Check
        tiles_needed = []
        is_connected = False
        is_first_move = (self.board[7][7] == '.')
        
        curr_r, curr_c = row, col
        for char in word:
            board_char = self.board[curr_r][curr_c]
            
            if board_char != '.':
                # Must match existing tile
                if board_char != char:
                    return False, None
                is_connected = True
            else:
                # Must use from rack
                tiles_needed.append(char)
                # Check neighbors for connectivity
                if not is_connected:
                    for nr, nc in [(curr_r+1, curr_c), (curr_r-1, curr_c), 
                                   (curr_r, curr_c+1), (curr_r, curr_c-1)]:
                        if 0 <= nr < 15 and 0 <= nc < 15 and self.board[nr][nc] != '.':
                            is_connected = True
                            break
            
            # First move check
            if is_first_move and curr_r == 7 and curr_c == 7:
                is_connected = True
                
            curr_r += dr
            curr_c += dc

        if not is_connected:
            return False, None

        # 3. Rack Counting (Handle Blanks)
        rack_counts = collections.Counter(rack)
        final_tiles_used = []
        
        for char in tiles_needed:
            if rack_counts[char] > 0:
                rack_counts[char] -= 1
                final_tiles_used.append(char)
            elif rack_counts['?'] > 0:
                rack_counts['?'] -= 1
                final_tiles_used.append('?') # Use blank
            else:
                return False, None # Missing tile

        return True, final_tiles_used

    def _legal_actions(self, player):
        if self._game_over or player != self._current_player:
            return []
            
        rack = self.racks[player]
        moves = self.get_game().move_gen.generate(self.board, rack)
        
        valid_moves = []
        
        for m in moves:
            # STRICT VALIDATION
            is_valid, _ = self._validate_move(m['row'], m['col'], m['word'], m['dir'], rack)
            if is_valid:
                valid_moves.append(m)

        if not valid_moves:
            return [450] # Pass

        # Deterministic Sorting
        valid_moves.sort(key=lambda x: (-len(x['word']), x['word']))

        best_moves_by_loc = {}
        for m in valid_moves:
            r, c, d_str = m['row'], m['col'], m['dir']
            d = 0 if d_str == 'Across' else 1
            action_id = (r * 15 + c) * 2 + d
            
            if action_id not in best_moves_by_loc:
                best_moves_by_loc[action_id] = m
        
        self._current_move_map = best_moves_by_loc
        
        legal = list(best_moves_by_loc.keys())
        if len(self.bag) >= 7:
            legal.append(451) 
            
        return sorted(legal)
    
    def legal_actions_mask(self, player=None):
        """
        Returns a list of 0s and 1s representing valid moves.
        Length must match game.num_distinct_actions() exactly (452).
        """
        if player is None:
            player = self.current_player()
        
        # Get the list of legal integer IDs (e.g. [2, 5, 450])
        legal_ids = self.legal_actions(player)
        
        # Create a mask of zeros with the correct length
        num_actions = self.get_game().num_distinct_actions() # Should be 452
        mask = [0] * num_actions
        
        # Set 1 for valid actions
        for action_id in legal_ids:
            if 0 <= action_id < num_actions:
                mask[action_id] = 1
            
        return mask

    def _apply_action(self, action_id):
        self.turn_count += 1
        if self.turn_count > 100:
            self._game_over = True
            return

        if action_id == 450: # PASS
            self.consecutive_passes += 1
            if self.consecutive_passes >= 6: self._game_over = True
            self._current_player = 1 - self._current_player
            self._current_move_map = {}
            return

        if action_id == 451: # EXCHANGE
            self.consecutive_passes += 1
            if self.consecutive_passes >= 6: self._game_over = True
            if len(self.bag) >= 7:
                self.bag.extend(self.racks[self._current_player])
                np.random.shuffle(self.bag)
                self.racks[self._current_player] = []
                self._refill_rack(self._current_player)
            self._current_player = 1 - self._current_player
            self._current_move_map = {}
            return

        # PLAY WORD
        if action_id not in self._current_move_map:
             self._legal_actions(self._current_player)

        # Safety Fallback
        if action_id not in self._current_move_map:
            # This should NEVER happen with the new _validate_move logic
            # But if it does, it's a Pass.
            self.consecutive_passes += 1
            self._current_player = 1 - self._current_player
            self._current_move_map = {}
            return

        move = self._current_move_map[action_id]
        row, col = move['row'], move['col']
        word = move['word']
        direction = move['dir']
        
        # Double check with validator to get tiles_used correctly
        is_valid, tiles_used = self._validate_move(row, col, word, direction, self.racks[self._current_player])
        
        if not is_valid:
            # Logic error: Generator said yes, Validator said no. Treat as Pass.
            self.consecutive_passes += 1
        else:
            # SUCCESSFUL EXECUTION
            self.consecutive_passes = 0
            score, _ = self._score_move(row, col, word, direction)
            self.scores[self._current_player] += score
            
            dr, dc = (0, 1) if direction == 'Across' else (1, 0)
            curr_r, curr_c = row, col
            for char in word:
                self.board[curr_r][curr_c] = char
                curr_r += dr
                curr_c += dc
                
            real_rack = self.racks[self._current_player]
            for char in tiles_used:
                if char in real_rack: real_rack.remove(char)
                else: real_rack.remove('?') # Blank

            self._refill_rack(self._current_player)
            if not self.racks[self._current_player] and not self.bag:
                self._game_over = True

        self._current_player = 1 - self._current_player
        self._current_move_map = {}
    
    def _score_move(self, row, col, word, direction):
        total_score = 0
        word_multiplier = 1
        cross_word_scores = 0
        tiles_used = [] 
        
        dr, dc = (0, 1) if direction == 'Across' else (1, 0)
        curr_r, curr_c = row, col
        
        move_score = 0
        
        for char in word:
            # SAFETY CHECK: If we go off board, stop scoring to prevent crash
            if not (0 <= curr_r < 15 and 0 <= curr_c < 15):
                break 

            # Check if tile already exists
            if self.board[curr_r][curr_c] != '.':
                move_score += TILE_VALUES[char]
            else:
                # Placed tile
                tiles_used.append(char)
                val = TILE_VALUES[char]
                
                prem = PREMIUMS.get((curr_r, curr_c))
                if prem:
                    ptype, pmult = prem
                    if ptype == 'L': val *= pmult
                    elif ptype == 'W': word_multiplier *= pmult
                
                move_score += val
                
                # Cross-Words
                cross_score = self._calc_cross_score(curr_r, curr_c, char, direction)
                cross_word_scores += cross_score

            curr_r += dr
            curr_c += dc
            
        total_score = (move_score * word_multiplier) + cross_word_scores
        
        if len(tiles_used) == 7:
            total_score += 50
            
        return total_score, tiles_used

    def _calc_cross_score(self, row, col, char, main_direction):
        # Calculate score of any word formed perpendicular to the main move
        # Returns 0 if no cross word is formed.
        cross_dr, cross_dc = (1, 0) if main_direction == 'Across' else (0, 1)
        
        # Check if neighbors exist
        if 0 <= row - cross_dr < 15 and 0 <= col - cross_dc < 15:
             if self.board[row-cross_dr][col-cross_dc] == '.':
                 if 0 <= row + cross_dr < 15 and 0 <= col + cross_dc < 15:
                     if self.board[row+cross_dr][col+cross_dc] == '.':
                         return 0 # No neighbors
        
        # Scan Back
        start_r, start_c = row, col
        while 0 <= start_r - cross_dr < 15 and 0 <= start_c - cross_dc < 15:
            if self.board[start_r - cross_dr][start_c - cross_dc] != '.':
                start_r -= cross_dr
                start_c -= cross_dc
            else:
                break
                
        # Scan Forward
        end_r, end_c = row, col
        while 0 <= end_r + cross_dr < 15 and 0 <= end_c + cross_dc < 15:
            if self.board[end_r + cross_dr][end_c + cross_dc] != '.':
                end_r += cross_dr
                end_c += cross_dc
            else:
                break
        
        # If start == end, it's just the single tile (not a word)
        if (start_r, start_c) == (end_r, end_c):
            return 0
            
        # Calculate Score for this cross word
        score = 0
        word_mult = 1
        
        curr_r, curr_c = start_r, start_c
        while True:
            # Is this the tile we just placed?
            if (curr_r, curr_c) == (row, col):
                val = TILE_VALUES[char]
                # Apply Premium (It applies to BOTH words!)
                prem = PREMIUMS.get((row, col))
                if prem:
                    ptype, pmult = prem
                    if ptype == 'L': val *= pmult
                    elif ptype == 'W': word_mult *= pmult
                score += val
            else:
                # Existing tile
                existing_char = self.board[curr_r][curr_c]
                score += TILE_VALUES[existing_char]
                
            if (curr_r, curr_c) == (end_r, end_c):
                break
            curr_r += cross_dr
            curr_c += cross_dc
            
        return score * word_mult

    def _action_to_string(self, player, action):
        return f"Move {action}"

    def is_terminal(self):
        return self._game_over

    def returns(self):
        # Return scores [player_1_score, player_2_score]
        return [0.0, 0.0]

    def information_state_tensor(self, player):
        planes = np.zeros((35, 15, 15), dtype=np.float32)
        
        # 0-25: Board Letters
        for r in range(15):
            for c in range(15):
                char = self.board[r][c]
                if 'A' <= char <= 'Z':
                    planes[ord(char) - ord('A')][r][c] = 1.0

        # 26: Blanks (Simplified: ignored for now, assuming all uppercase)
        
        # 27-30: Bonuses
        for r in range(15):
            for c in range(15):
                prem = PREMIUMS.get((r, c))
                if prem:
                    t, v = prem
                    if t=='L' and v==2: planes[27][r][c] = 1.0
                    if t=='L' and v==3: planes[28][r][c] = 1.0
                    if t=='W' and v==2: planes[29][r][c] = 1.0
                    if t=='W' and v==3: planes[30][r][c] = 1.0

        # 31: Anchors
        # (Re-calculate anchors quickly)
        for r in range(15):
            for c in range(15):
                if self.board[r][c] == '.':
                    if (r>0 and self.board[r-1][c]!='.') or (r<14 and self.board[r+1][c]!='.') or \
                       (c>0 and self.board[r][c-1]!='.') or (c<14 and self.board[r][c+1]!='.'):
                        planes[31][r][c] = 1.0
        if self.board[7][7] == '.': planes[31][7][7] = 1.0

        # 32: Bag Percentage (Constant Plane)
        bag_val = len(self.bag) / 100.0
        planes[32].fill(bag_val)

        # 33: Score Ratio (Me / (Me+Opponent))
        s1, s2 = self.scores[player], self.scores[1-player]
        total = s1 + s2 + 1e-5
        planes[33].fill(s1 / total)

        # 34: My Rack (Projected onto diagonal? No, standard practice is a constant plane per letter)
        # This is tricky for variable racks. Let's just use channel 34 as "Rack Density" for now
        # to prevent shape errors, or leave empty.
        # Ideally, we add 26 more channels for the rack, but let's stick to 35 total for memory.
        
        return planes.flatten()
    
    def observation_tensor(self, player=None):
        """
        Required by AlphaZero. 
        Maps the specific player's view (Information State) to the observation.
        """
        # If player is not specified, default to the current player
        if player is None:
            player = self.current_player()
            
        return self.information_state_tensor(player)
    
    def __str__(self):
        # Create a simple ASCII representation
        lines = []
        lines.append(f"Turn: Player {self._current_player}")
        lines.append(f"Scores: P0={self.scores[0]} P1={self.scores[1]}")
        lines.append(f"Bag: {len(self.bag)} tiles")
        lines.append("   " + " ".join([chr(ord('A') + i) for i in range(15)]))
        for r in range(15):
            row_str = f"{r:2} "
            for c in range(15):
                row_str += self.board[r][c] + " "
            lines.append(row_str)
        return "\n".join(lines)

# Register the game
pyspiel.register_game(_GAME_TYPE, ScrabbleGame)

if __name__ == "__main__":
    game = pyspiel.load_game("scrabble")
    state = game.new_initial_state()
    print("Board initialized.")
    print("Legal actions:", state.legal_actions())
    # Try applying action 2 (First real move)
    state.apply_action(2)
    print("Move played.")
    print(state.board)